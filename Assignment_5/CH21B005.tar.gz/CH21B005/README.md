## Assignment 5 - CS6040

**Submission by: Aditya K (CH21B005)**

Command to run the program for a particular input

```
make
./spt -p RuleFile -i InputAddrFile -o OutputFile
```

The sample input files are `ips` and `rules`. The sample output file is `outputfile`.
